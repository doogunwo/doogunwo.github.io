#include <stdint.h>

#define UART0_BASE 0xFFC02000u

#define UART_RBR 0x00u
#define UART_THR 0x00u
#define UART_LSR 0x14u

#define UART_LSR_THRE (1u << 5)
#define UART_LSR_DR (1u << 0)

#define UART_RECEIVE_DATA 0x00u



static inline uint32_t mmio_read(uint32_t addr)
{
    return *(volatile uint32_t *)addr;
}

static inline void mmio_write(uint32_t addr, uint32_t value)
{
    *(volatile uint32_t *) addr = value;
}

char uart_getc(void)
{
    while(!(mmio_read(UART0_BASE + UART_LSR) & UART_LSR_DR)){}
    return (char)mmio_read(UART0_BASE + UART_RECEIVE_DATA);
}

void uart_putc(char c)
{
    while (!(mmio_read(UART0_BASE + UART_LSR) & UART_LSR_THRE)) {
}

    mmio_write(UART0_BASE + UART_THR, (uint32_t)(unsigned char)c);
}

void uart_puts(const char *str)
{
    while (*str) {
        if (*str == '\n') {
            uart_putc('\r');
        }
        uart_putc(*str++);
    }
}

int main(void)
{
    uart_puts("Hello Cortex-A9!\n");
    while (1) {
        int a = uart_getc() - '0';
        int b = uart_getc() - '0';
        int sum = a+b;
        if (sum >= 10) {
            uart_putc('1');
        }

        uart_putc('0' + (sum%10));
        uart_putc('\n');
    }
}