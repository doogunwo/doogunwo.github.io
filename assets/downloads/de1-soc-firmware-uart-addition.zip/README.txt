DE1-SoC UART 덧셈 펌웨어 실습

main.c, startup.S, linker.ld는 실습 당시 작업 파일입니다.
입력은 공백 없이 0~9 숫자 두 문자이며, 결과는 0~18입니다.
UART 설정을 끝낸 부트로더를 먼저 실행해야 합니다.
보드 CPU는 ARM 상태이며 MMU와 데이터 캐시가 꺼져 있어야 합니다.
프로그램은 JTAG로 RAM에 올립니다. UART로 BIN을 받는 부트로더 기능은 아직 없습니다.

firmware 폴더에서 빌드:
arm-none-eabi-gcc -mcpu=cortex-a9 -marm -O0 -g \
  -ffreestanding -nostdlib -Wall -Wextra -Werror \
  -fno-unwind-tables -fno-asynchronous-unwind-tables \
  -T linker.ld startup.S main.c -o firmware.elf

바이너리 변환:
arm-none-eabi-objcopy -O binary firmware.elf firmware.bin

GDB에서 CPU를 멈추고 올린 뒤 실행:
monitor halt
file /자신의/경로/firmware.elf
load
monitor arm mcr 15 0 7 10 4 0
monitor arm mcr 15 0 7 5 0 0
monitor arm mcr 15 0 7 10 4 0
monitor arm mcr 15 0 7 5 4 0
set $pc = &_start
continue

UART 출력 터미널을 열어둔 상태에서 다른 터미널로 전송:
printf '34' | sudo tee /dev/ttyUSB0 > /dev/null

예상 결과: 7
GDB로 CPU를 멈춘 동안에는 전송하지 않습니다.
자세한 준비 과정은 블로그의 이전 부트로더 실습 글을 참고하세요.
