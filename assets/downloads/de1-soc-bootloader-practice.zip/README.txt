DE1-SoC HPS Cortex-A9 CPU0 bare-metal practice

This source snapshot corresponds to the blog post De1-Soc 기반 펌웨어 실습.

Prerequisites: ARM bare-metal GCC/binutils, gdb-multiarch, Quartus OpenOCD
with the aji_client adapter, USB-Blaster II and USB-to-UART connections.
Run from bootloader/:
  ./execute.sh
  ./execute.sh jtag
  sudo ./execute.sh uart   (separate terminal, before continuing in GDB)

Open another terminal and run:
  gdb-multiarch bootloader.elf
GDB commands:
  target remote localhost:3333
  monitor halt
  load
  set $cpsr = ($cpsr & ~0x20)
  set $pc = &_start
  tbreak main
  continue
At main, start the UART reader, then continue again.

The default Quartus directory in execute.sh is machine-specific.
Set QUARTUS_ROOTDIR to your own Quartus installation directory if different.
Expected start state: CPU0 privileged ARM state, MMU and D-cache disabled,
25 MHz cold-reset Safe Mode, source loaded into OCRAM.
The application uses polling and has no wait timeouts.
This snapshot implements the startup and UART output stage only;
it does not receive or launch a second firmware image.

uart_iocsr.h retains the BSD-3-Clause SPDX notice and source attribution
for the DE1-SoC IOCSR chain 2 table from U-Boot.
