#!/usr/bin/env bash
set -euo pipefail

# 어느 폴더에서 실행하든 이 스크립트가 있는 폴더를 기준으로 빌드한다.
cd -- "$(dirname -- "${BASH_SOURCE[0]}")"

# ./execute.sh: 빌드. jtag: 빌드 후 JTAG 서버 실행. uart: UART 출력 보기.
if [[ $# -gt 1 || ( $# -eq 1 && "$1" != "jtag" && "$1" != "uart" ) ]]; then
    echo "사용법: $0 [jtag|uart]" >&2
    exit 1
fi

# UART를 볼 때는 다시 빌드하지 않고 현재 실행 중인 보드의 출력을 읽는다.
if [[ "${1:-}" == "uart" ]]; then
    stty -F /dev/ttyUSB0 57600 raw -echo cs8 -parenb -cstopb \
        -ixon -ixoff -crtscts clocal
    echo "UART 출력 대기: /dev/ttyUSB0, 57600 baud, 8N1 (종료: Ctrl+C)"
    exec cat /dev/ttyUSB0
fi

# 1. 링커 파일 생성
gcc -E -P -x c linker.ld.S -o linker.ld

# 2. 시작 코드와 C 코드를 함께 빌드하여 ELF 생성
arm-none-eabi-gcc \
    -mcpu=cortex-a9 -marm -O0 -g \
    -ffreestanding -fno-unwind-tables -fno-asynchronous-unwind-tables \
    -nostdlib -Wall -Wextra -Werror \
    -Wl,--build-id=none -T linker.ld \
    startup.S main.c board.c \
    -o bootloader.elf

echo "빌드 완료: bootloader.elf"

# 3. 요청한 경우 Quartus의 OpenOCD로 JTAG 연결을 연다.
if [[ "${1:-}" == "jtag" ]]; then
    quartus_root="${QUARTUS_ROOTDIR:-/storage/tools/intelFPGA_lite/24.1/quartus}"
    echo "JTAG 서버 시작: GDB는 127.0.0.1:3333으로 연결"
    exec "$quartus_root/bin/openocd" -f jtag.cfg
fi
