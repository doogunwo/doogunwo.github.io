/*
 * 전원 직후 UART 핀을 쓰기 위해 필요한 DE1-SoC 설정.
 * main.c의 UART 속도/송신 코드와 분리한 보드 준비 절차다.
 *
 * UART 핀은 HPS I/O bank 7A에 있다. bank의 전기적 설정을 먼저
 * 적용하고 RX/TX 기능을 선택한 뒤 핀의 freeze 상태를 해제한다.
 * PDF 참고: 303~304쪽(UART mux), 405~412쪽(scan), 217~218쪽(freeze).
 *
 * 실행 전제: CPU0 privileged 모드, OCRAM에서 실행, 스택 준비 완료.
 * PLL을 재설정하지 않고 콜드 리셋의 25 MHz Safe Mode를 유지한다.
 */
#include <stdint.h>
#include "uart_iocsr.h"

/* 이 파일에서만 사용하는 하드웨어 레지스터 접근 매크로 */
#define REG32(address) (*(volatile uint32_t *)(uintptr_t)(address))

#define CLOCK_CTRL       0xFFD04000u
#define PERIPHERAL_RESET 0xFFD05014u
#define IO_FREEZE        0xFFD08048u
#define UART_RX_MUX      0xFFD08484u
#define UART_TX_MUX      0xFFD08488u
#define SCAN_STATUS      0xFFF02000u
#define SCAN_ENABLE      0xFFF02004u
#define SCAN_HEADER      0xFFF02014u
#define SCAN_DATA        0xFFF0201Cu

void board_delay(void)
{
    __asm__ volatile ("dsb sy" ::: "memory");
    for (uint32_t i = 0; i < 32u; ++i) {
        __asm__ volatile ("nop");
    }
}

static void scan_wait(void)
{
    /* ACTIVE와 쓰기 FIFO의 데이터 수가 모두 0이 될 때까지 기다린다. */
    while ((REG32(SCAN_STATUS) & 0xF0000000u) != 0u) {
    }
}

static void uart_pins_init(void)
{
    REG32(IO_FREEZE) &= ~0x1Cu; /* slew / pullup / tristate */
    board_delay();
    REG32(IO_FREEZE) &= ~0x03u; /* bus hold / configuration */
    board_delay();

    scan_wait();
    REG32(SCAN_ENABLE) = 1u << 2; /* scan chain 2: bank 7A */
    board_delay();

    /* 설정 955 bits를 128 bits씩 보낸다. 마지막 묶음은 59 bits. */
    for (uint32_t bit = 0; bit < UART_IOCSR_BITS; bit += 128u) {
        uint32_t count = UART_IOCSR_BITS - bit;
        if (count > 128u) {
            count = 128u;
        }
        REG32(SCAN_HEADER) = 0x80u | ((count - 1u) << 8);
        board_delay();

        /* 이 표의 묶음은 128 또는 59 bits라서 32-bit 쓰기로 전송할 수 있다. */
        for (uint32_t j = 0; j < (count + 31u) / 32u; ++j) {
            REG32(SCAN_DATA) = uart_iocsr_words[bit / 32u + j];
            board_delay();
        }
        scan_wait();
    }
    REG32(SCAN_ENABLE) = 0u;
    board_delay();

    REG32(UART_RX_MUX) = 1u; /* GPIO49 -> UART0 RX */
    REG32(UART_TX_MUX) = 1u; /* GPIO50 -> UART0 TX */
    board_delay();

    REG32(IO_FREEZE) |= 0x03u; /* 설정 적용, bus hold 허용 */
    board_delay();
    REG32(IO_FREEZE) |= 0x0Cu; /* pullup / tristate를 설정값에 맡김 */
    board_delay();
    REG32(IO_FREEZE) |= 0x10u; /* slew-rate를 설정값에 맡김 */
    board_delay();
}

int board_init(void)
{
    uint32_t cpu_control;

    __asm__ volatile ("cpsid if" ::: "memory"); /* IRQ/FIQ 차단 */
    __asm__ volatile ("mrc p15, 0, %0, c1, c0, 0" : "=r" (cpu_control));

    /* MMU/D-cache가 꺼져 있고 클럭이 Safe Mode인지 확인한다. */
    if ((cpu_control & 0x05u) != 0u || (REG32(CLOCK_CTRL) & 1u) == 0u) {
        return -1;
    }

    /* bit 16: UART0 reset. bit 6/7: L4 watchdog을 reset 상태로 유지. */
    REG32(PERIPHERAL_RESET) |= (1u << 16) | (1u << 6) | (1u << 7);
    board_delay();

    uart_pins_init();

    REG32(PERIPHERAL_RESET) &= ~(1u << 16); /* UART0 reset 해제 */
    board_delay();
    return 0;
}
