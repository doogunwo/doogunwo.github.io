/* SPDX-License-Identifier: BSD-3-Clause */
/*
 * Altera SoCFPGA IOCSR configuration: DE1-SoC HPS I/O bank 7A.
 * U-Boot board/terasic/de1-soc/qts/iocsr_config.h에서 scan chain 2만 발췌.
 * https://github.com/u-boot/u-boot/blob/master/board/terasic/de1-soc/qts/iocsr_config.h
 * Quartus가 생성한 전기적 I/O 설정값이다. 메모리 주소 목록이 아니다.
 */
#ifndef DE1_SOC_UART_IOCSR_H
#define DE1_SOC_UART_IOCSR_H

#include <stdint.h>

#define UART_IOCSR_BITS 955u

static const uint32_t uart_iocsr_words[] = {
    0x300C0300u,
    0x00000000u,
    0x0FF00000u,
    0x00000000u,
    0x000300C0u,
    0x00008000u,
    0x00080000u,
    0x18060000u,
    0x18000000u,
    0x00018060u,
    0x00020000u,
    0x00004000u,
    0x200300C0u,
    0x10000000u,
    0x00000000u,
    0x00000040u,
    0x00010000u,
    0x00002000u,
    0x10018060u,
    0x06018000u,
    0x06000000u,
    0x00010018u,
    0x00006018u,
    0x00001000u,
    0x0000C030u,
    0x00000000u,
    0x03000000u,
    0x0000800Cu,
    0x00C0300Cu,
    0x00000800u,
};

_Static_assert(sizeof(uart_iocsr_words) / sizeof(uart_iocsr_words[0]) ==
               (UART_IOCSR_BITS + 31u) / 32u, "IOCSR table length");

#endif
