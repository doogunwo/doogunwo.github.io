/*
 * 첫 목표: 하드웨어를 준비하고 UART로 한 줄 출력한다.
 * 전원 재인가 후 OCRAM에서 실행한다. 클럭은 초기 Safe Mode의 25 MHz.
 * startup.S의 스택 준비와 linker.ld의 코드 배치는 별도로 필요하다.
 */
#define UART0_BASE  0xFFC02000u
#define UART_DATA   (UART0_BASE + 0x00u) /* 송신 데이터 / 속도 분주값 하위 */
#define UART_IER    (UART0_BASE + 0x04u) /* 인터럽트 / 속도 분주값 상위 */
#define UART_LCR    (UART0_BASE + 0x0Cu) /* 문자 형식과 레지스터 선택 */
#define UART_LSR    (UART0_BASE + 0x14u) /* 송수신 상태 */
#include <stdint.h>

/* board.c에 구현된 함수 선언 */
int board_init(void);
void board_delay(void);

uint32_t reg_read(uint32_t address)
{
    volatile uint32_t *reg = (volatile uint32_t *)(uintptr_t)address;
    return *reg;
}

void reg_write(uint32_t address, uint32_t value)
{
    volatile uint32_t *reg = (volatile uint32_t *)(uintptr_t)address;
    *reg = value;
}

void uart_init(void)
{
    reg_write(UART_LCR, 0x03u); // 8N1 설정
    reg_write(UART_IER, 0u);    // 인터럽트 끄기

    reg_write(UART_LCR, 0x83u); // 분주값 설정 모드
    reg_write(UART_DATA, 27u);  // 분주값 하위
    reg_write(UART_IER, 0u);    // 분주값 상위
    reg_write(UART_LCR, 0x03u); // 송수신 모드로 복귀

    board_delay();
}

static void uart_putc(char ch)
{   
    // 송신할 준비가 될때 까지 기다림
    while ((reg_read(UART_LSR) & (1u << 5)) == 0u) {}
    reg_write(UART_DATA, (uint32_t)(unsigned char) ch);
}

static void uart_puts(const char *text)
{
    while (*text != '\0') {
        uart_putc(*text++);
    }
}

int main(void)
{
    /* 보드의 필수 핀 설정과 UART 리셋 해제를 먼저 한다. */
    if (board_init() != 0) {
        while (1) {
        }
    }

    uart_init();
    uart_puts("Bootloader ready\r\n");

    while (1) {
    }
}
